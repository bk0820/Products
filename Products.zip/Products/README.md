#Endpoints
/products
/products/{id}
/products/pqty

#H2 Endpoint
/h2-console
JDBC URL : jdbc:h2:mem:productdb
Username : product
Password : password