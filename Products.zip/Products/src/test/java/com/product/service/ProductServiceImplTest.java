package com.product.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.product.entities.Product;
import com.product.exceptions.ProductException;
import com.product.repositories.ProductQtyVO;
import com.product.repositories.ProductRepository;

public class ProductServiceImplTest {
	
	@InjectMocks
	private ProductSvcImpl productSvcImpl;
	
	@Mock
	private ProductRepository productRepository;

	
	@Before
	public void before() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void testIsDiscounted() throws ProductException {
		Product product = Mockito.mock(Product.class);
		Mockito.when(productRepository.findById(1L)).thenReturn(Optional.of(product));
		Mockito.when(product.isDiscounted()).thenReturn(true);
		Assert.assertTrue(productSvcImpl.isDicounted(1L));
	}
	
	@Test
	public void testGetAllProducts() {
		List<Product> products = getProductList();
		Mockito.when(productRepository.getAllProducts()).thenReturn(products);
		List<String> productsList = productSvcImpl.getAllProducts();
		Assert.assertEquals(products.size(), productsList.size());
		Assert.assertEquals("2|(999.0)", productsList.get(0));
		Assert.assertEquals("1|123.98", productsList.get(1));
	}
	
	@Test
	public void testQuantitySoldByProductType() {
		ProductQtyVO productQtyVO = Mockito.mock(ProductQtyVO.class);
		List<ProductQtyVO> productQtyVOs = new ArrayList<>();
		productQtyVOs.add(productQtyVO);
		Mockito.when(productRepository.quantitySoldByProductType()).thenReturn(productQtyVOs);
		Assert.assertEquals(productQtyVOs, productSvcImpl.quantitySoldByProductType());
	}
	
	private List<Product> getProductList() {
		List<Product> productsList = new ArrayList<>();
		Product product = new Product();
		product.setDiscounted(false);
		product.setPrice(123.98d);
		product.setId(1);
		
		Product product2 = new Product();
		product2.setDiscounted(true);
		product2.setPrice(999d);
		product2.setId(2);
		
		productsList.add(product2);
		productsList.add(product);
		return productsList;
	}
}
