package com.product;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.product.entities.Product;
import com.product.repositories.ProductRepository;

@Component
public class ProductsSetup implements CommandLineRunner {
	
	@Autowired
	private ProductRepository productRepository;

	@Override
	public void run(String... args) throws Exception {
		
		Product product = new Product();
		product.setDiscounted(false);
		product.setPrice(123.98d);
		product.setProductType("T1");
		productRepository.save(product);
		
		product = new Product();
		product.setDiscounted(true);
		product.setPrice(999d);
		product.setProductType("T1");
		productRepository.save(product);
		
		
		product = new Product();
		product.setDiscounted(true);
		product.setPrice(58d);
		product.setProductType("T1");
		productRepository.save(product);
		
		
		product = new Product();
		product.setDiscounted(false);
		product.setPrice(8787);
		product.setProductType("T1");
		productRepository.save(product);
		
		
		product = new Product();
		product.setDiscounted(true);
		product.setPrice(6565);
		product.setProductType("T2");
		productRepository.save(product);
		
		
		product = new Product();
		product.setDiscounted(true);
		product.setPrice(1211);
		product.setProductType("T2");
		productRepository.save(product);
		
		
		product = new Product();
		product.setDiscounted(false);
		product.setPrice(9765);
		product.setProductType("T2");
		productRepository.save(product);
		
	}

}
