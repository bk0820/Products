package com.product.exceptions;

public class ProductException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3563619877440008966L;

	public ProductException(String error) {
		super(error);
	}
}
