package com.product.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.product.entities.Product;
import com.product.exceptions.ProductException;
import com.product.repositories.ProductQtyVO;
import com.product.repositories.ProductRepository;

@Service
public class ProductSvcImpl implements ProductSvc {

	@Autowired
	private ProductRepository productRepository;

	@Override
	public boolean isDicounted(long productId) throws ProductException {
		if (productId > 0) {
			Optional<Product> product = productRepository.findById(productId);
			if (product.isPresent())
				return product.get().isDiscounted();
			else
				throw new ProductException("Could not find the requested product.");
		} else {
			throw new IllegalArgumentException("Product ID is not Valid");
		}
	}

	@Override
	public List<String> getAllProducts() {
		return productRepository.getAllProducts().stream().map(product -> {
			if (product.isDiscounted())
				return product.getId() + "|(" + product.getPrice() + ")";
			else
				return product.getId() + "|" + product.getPrice();
		}).collect(Collectors.toList());
	}

	@Override
	public List<ProductQtyVO> quantitySoldByProductType() {
		return productRepository.quantitySoldByProductType();
	}

}
