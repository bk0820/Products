package com.product.service;

import java.util.List;

import com.product.exceptions.ProductException;
import com.product.repositories.ProductQtyVO;

public interface ProductSvc {

	public boolean isDicounted(long productId) throws ProductException;
	
	public List<String> getAllProducts();
	
	public List<ProductQtyVO> quantitySoldByProductType();
}
