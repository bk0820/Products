package com.product.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.product.exceptions.ProductException;
import com.product.repositories.ProductQtyVO;
import com.product.service.ProductSvc;

@RestController
@RequestMapping("products")
public class ProductController {

	@Autowired
	private ProductSvc productSvc;
	
	@GetMapping("/{id}")
	public ResponseEntity<Boolean> isDiscounted(@PathVariable("id") Long id) throws ProductException {
		return new ResponseEntity<Boolean>(productSvc.isDicounted(id), HttpStatus.ACCEPTED);
	}
	
	@GetMapping
	public ResponseEntity<List<String>> getAllProducts() {
		return new ResponseEntity<List<String>>(productSvc.getAllProducts(), HttpStatus.ACCEPTED);
	}
	
	@GetMapping("/pqty")
	public ResponseEntity<List<ProductQtyVO>> quantitySoldByProductType() {
		return new ResponseEntity<List<ProductQtyVO>>(productSvc.quantitySoldByProductType(), HttpStatus.ACCEPTED);
	}
	
}
