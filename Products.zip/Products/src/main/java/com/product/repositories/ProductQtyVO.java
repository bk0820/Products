package com.product.repositories;

import java.io.Serializable;

public class ProductQtyVO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8968683372290474072L;

	public ProductQtyVO(String productType, long quantity) {
		super();
		this.productType = productType;
		this.quantity = quantity;
	}

	private String productType;
	
	private long quantity;

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public long getQuantity() {
		return quantity;
	}

	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}
	
	

}
