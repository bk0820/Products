package com.product.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.product.entities.Product;

@Repository
public interface ProductRepository extends CrudRepository<Product, Long> {


	@Query("from Product p order by p.discounted desc")
	List<Product> getAllProducts();
	
	@Query("Select new com.product.repositories.ProductQtyVO(p.productType, count(p.id)) from Product p group by p.productType")
	List<ProductQtyVO> quantitySoldByProductType();
}
